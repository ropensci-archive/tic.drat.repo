library(testthat)
library(ticdrat)

test_check("ticdrat")
