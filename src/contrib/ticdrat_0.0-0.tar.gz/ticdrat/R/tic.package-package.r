#' @details
#' For demonstration of the \pkg{tic} package.
#' @examples
#' # Show timestamp
#' Sys.time()
"_PACKAGE"

#' @useDynLib ticdrat
#' @importFrom Rcpp sourceCpp
NULL
