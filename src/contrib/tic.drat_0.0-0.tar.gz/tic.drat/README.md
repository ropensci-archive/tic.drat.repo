# tic.drat

[![Travis-CI Build Status](https://travis-ci.org/krlmlr/tic.drat.svg?branch=master)](https://travis-ci.org/krlmlr/tic.drat) [![AppVeyor Build Status](https://ci.appveyor.com/api/projects/status/github/krlmlr/tic.drat?branch=master&svg=true)](https://ci.appveyor.com/project/krlmlr/tic.drat) [![Coverage Status](https://codecov.io/gh/krlmlr/tic.drat/branch/master/graph/badge.svg)](https://codecov.io/github/krlmlr/tic.drat?branch=master)

A minimal example package with pkgdown documentation created and uploaded by tic.
