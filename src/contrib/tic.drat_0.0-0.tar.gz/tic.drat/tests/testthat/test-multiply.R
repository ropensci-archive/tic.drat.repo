context("multiply")

test_that("multiplication works", {
  expect_equal(multiply(2, 3), 6)
})
