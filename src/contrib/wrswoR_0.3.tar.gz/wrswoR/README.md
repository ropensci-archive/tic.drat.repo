wrswoR [![wercker status](https://app.wercker.com/status/0ac22bbb960f58cf3ba31c4bd175270c/s/master "wercker status")](https://app.wercker.com/project/bykey/0ac22bbb960f58cf3ba31c4bd175270c) [![AppVeyor Build Status](https://ci.appveyor.com/api/projects/status/github/krlmlr/wrswoR?branch=master)](https://ci.appveyor.com/project/krlmlr/wrswoR) [![codecov.io](https://codecov.io/github/krlmlr/wrswoR/coverage.svg?branch=master)](https://codecov.io/github/krlmlr/wrswoR?branch=master)
======

A package with different implementations of weighted random sampling without replacement in R.

```
library(devtools)
install_github('wrswoR', 'krlmlr')
```
