library(testthat)
library(wrswoR)

test_check("wrswoR")
